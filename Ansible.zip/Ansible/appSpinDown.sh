#!/bin/bash

setV='$set'
andq='$and'
servers="CLPVDPNSVN01 CLPVTPNDBS01 CLPVTPNDBS03"
rm -rf appSpindownStatus.log
rm -rf appSpindownRunning.log 

for host in $servers
 do
#	echo $host >>serviceStatus.log
	echo $host:$(ssh $host 'service tomcat status') >> appSpindownStatus.log
	echo $host:$(ssh $host 'service tomcat status') >> appSpindownRunning.log
done

echo $(cat appSpindownStatus.log | grep "not running" | cut -d: -f1) > appSpindownStatus.log
echo $(cat appSpindownRunning.log | grep "Tomcat is running" | cut -d: -f1) > appSpindownRunning.log
#echo $myArray[0]

#eeho $(cat serviceStatus.log | cut -d" " -f1)
serverName=$(awk -F ' ' '{print $1}' appSpindownStatus.log)
myarray[1]=$serverName
serverName=$(awk -F ' ' '{print $2}' appSpindownStatus.log)
myarray[2]=$serverName
serverName=$(awk -F ' ' '{print $3}' appSpindownStatus.log)
myarray[3]=$serverName
echo ${myarray[@]}

appServerName=$(awk -F ' ' '{print $1}' appSpindownRunning.log)
appServerArray[1]=$appServerName
appServerName=$(awk -F ' ' '{print $2}' appSpindownRunning.log)
appServerArray[2]=$appServerName
appServerName=$(awk -F ' ' '{print $3}' appSpindownRunning.log)
appServerArray[3]=$appServerName
echo ${appServerArray[@]}


#EVAL="db.mycollection.find({\"hostName\":\"${myarray[1]\"})"
#echo $EVAL | mongo localhost:27017/dashboard --quiet

for i in {1..3}
do
	#mongo localhost:27017/dashboard  -eval "db.mycollection.find({\"hostName\":\"${myarray[i]}\"})"
 	# mongo localhost:27017/dashboard  -eval	"db.mycollection.update({\"hostName\":\"${myarray[i]}\",\"status\" : \"False\"})"
	# mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"${myarray[i]}\"},{$setV:{\"Appstatus\":\"False\"}})"
	mongo localhost:27017/dashboard  -eval	"db.mycollection1.update({$andq: [{\"hostName\" : \"${myarray[i]}\"},{\"type\" : \"appserver\"}]},{$setV:{\"applicationName\":\" \"}})"
	mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${myarray[i]}\"},{\"type\" : \"appserver\"}]},{$setV:{\"appserver\":\" \"}})"
	mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${myarray[i]}\"},{\"type\" : \"appserver\"}]},{$setV:{\"Appstatus\":\"False\"}})"
	mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${myarray[i]}\"},{\"type\" : \"appserver\"}]},{$setV:{\"javaVesion\":\" \"}})"	

done

for i in {1..3}
do
        #mongo localhost:27017/dashboard  -eval "db.mycollection.find({\"hostName\":\"${myarray[i]}\"})"
        # mongo localhost:27017/dashboard  -eval        "db.mycollection.update({\"hostName\":\"${myarray[i]}\",\"status\" : \"False\"})"
        # mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"${appServerArray[i]}\"},{$setV:{\"Appstatus\":\"True\"}})"
	mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${appServerArray[i]}\"},{\"type\" : \"appserver\"}]},{$setV:{\"Appstatus\":\"True\"}})"
	 mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${appServerArray[i]}\"},{\"type\" : \"appserver\"}]},{$setV:{\"applicationName\":\"Asset-Registry\"}})"
	mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${appServerArray[i]}\"},{\"type\" : \"appserver\"}]},{$setV:{\"appserver\":\"Apache-Tomcat-7\"}})"
	 mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${appServerArray[i]}\"},{\"type\" : \"appserver\"}]},{$setV:{\"javaVesion\":\"Java-8\"}})"

done

