#!/bin/bash

cd /etc/ansible/
ansible-playbook dashboardSpinDown.yml  --extra-vars "target=$1"
