#!/bin/bash

mongo dashboard  --eval "db.createCollection('mycollection2')"
