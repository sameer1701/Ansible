#!/bin/bash

serverList="clpvdpnsvn01 CLPVTPNDBS03 CLPVTPNDBS01"

for host in $serverList
do 
	server_status=$(ssh $host service tomcat status)
	#echo $host: $server_status
	
	if [[ ! "$server_status" =~ ^.*pid.*$ ]]
	then
		echo down $host
		ansible-playbook ../dashboardSpinUP.yml --extra-vars "target=$host"
	fi
done

