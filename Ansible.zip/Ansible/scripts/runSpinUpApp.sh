#!/bin/bash

ansible-playbook ../dashboardSpinUP.yml  --extra-vars "target=$1"
