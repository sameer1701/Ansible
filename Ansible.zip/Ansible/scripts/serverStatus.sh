#!/bin/bash

setV='$set'
servers="clpvdpnsvn01 CLPVTPNDBS01 CLPVTPNDBS03"
rm -rf serviceStatus.log

for host in $servers
 do
#	echo $host >>serviceStatus.log
	echo $host:$(ssh $host 'service tomcat status') >>serviceStatus.log
done

echo $(cat serviceStatus.log | grep "not running" | cut -d: -f1) > serviceStatus.log
#echo $myArray[0]

#eeho $(cat serviceStatus.log | cut -d" " -f1)
serverName=$(awk -F ' ' '{print $1}' serviceStatus.log)
myarray[1]=$serverName
serverName=$(awk -F ' ' '{print $2}' serviceStatus.log)
myarray[2]=$serverName
serverName=$(awk -F ' ' '{print $3}' serviceStatus.log)
myarray[3]=$serverName
echo ${myarray[@]}

#EVAL="db.mycollection.find({\"hostName\":\"${myarray[1]\"})"
#echo $EVAL | mongo localhost:27017/dashboard --quiet

for i in {1..3}
do
	#mongo localhost:27017/dashboard  -eval "db.mycollection.find({\"hostName\":\"${myarray[i]}\"})"
 	# mongo localhost:27017/dashboard  -eval	"db.mycollection.update({\"hostName\":\"${myarray[i]}\",\"status\" : \"False\"})"
	 mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"${myarray[i]}\"},{$setV:{\"status\":\"False\"}})"
done
 
<<comment
while read line
do
echo $line 
myarray=$(echo $line | grep "not running" | cut -d: -f1)
done <serviceStatus.log
echo $myarray[@]
comment
