#!/bin/bash

ansible-playbook ../dashboardSpinUpDB.yml  --extra-vars "target=$1"
