#!/bin/bash
setV='$set'
andq='$and'
servers="CLPVDPNSVN01 CLPVTPNDBS01 CLPVTPNDBS03 CLPVTPNDBS02"

rm -rf sizePerc.log

for host in $servers
do
	echo $(ssh $host df -h /data | tail -n 1 | awk '{print $4}') >> sizePerc.log
	
done

echo $(cat sizePerc.log |  cut -d" " -f1) > sizePerc.log


server1=$(awk -F ' ' '{print $1}' sizePerc.log)
myarray[1]=$server1
server2=$(awk -F ' ' '{print $2}' sizePerc.log)
myarray[2]=$server2
server3=$(awk -F ' ' '{print $3}' sizePerc.log)
myarray[3]=$server3
server4=$(awk -F ' ' '{print $4}' sizePerc.log)
myarray[4]=$server4

serversName=(CLPVDPNSVN01 CLPVTPNDBS01 CLPVTPNDBS03 CLPVTPNDBS02)

#echo servername1:${serversName[1]}
#mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"clpvdpnsvn01\"},{$setV:{\"available_size\":\"$server1\"}})"
#mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"CLPVTPNDBS01\"},{$setV:{\"available_size\":\"$server2\"}})"
#mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"CLPVTPNDBS03\"},{$setV:{\"available_size\":\"$server3\"}})"
#mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"CLPVTPNDBS02\"},{$setV:{\"available_size\":\"$server4\"}})"

for i in {1..4}
do
        mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${serversName[i]}\"},{\"type\" : \"appserver\"}]},{$setV:{\"available_size_percentage\":\"${myarray[i]}\"}})"
	mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${serversName[i]}\"},{\"type\" : \"DBServer\"}]},{$setV:{\"available_size_percentage\":\"${myarray[i]}\"}})"

done



