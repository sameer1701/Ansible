#!/bin/bash

ansible-playbook ../dashboardSpinDownDB.yml  --extra-vars "target=$1"
