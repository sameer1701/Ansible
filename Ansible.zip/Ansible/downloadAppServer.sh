#!/bin/bash

scp /data/Software/apache-tomcat-7.0.61.tar.gz clpvdpnsvn01:/tmp/
