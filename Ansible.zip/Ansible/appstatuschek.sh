#!/bin/bash

setV='$set'
andq='$and'
servers="clpvdpnsvn01 CLPVTPNDBS01 CLPVTPNDBS03"
rm -rf serviceStatus.log
rm -rf serviceStatusRunning.log

for host in $servers
 do
#       echo $host >>serviceStatus.log
        echo $host:$(ssh $host 'service tomcat status') >> serviceStatus.log
        echo $host:$(ssh $host 'service tomcat status') >> serviceStatusRunning.log
done

echo $(cat serviceStatus.log | grep "not running" | cut -d: -f1) > serviceStatus.log
echo $(cat serviceStatusRunning.log | grep "Tomcat is running" | cut -d: -f1) > serviceStatusRunning.log
#echo $myArray[0]

