#!/bin/bash

setV='$set'
andq='$and'
servers="CLPVTPNDBS02 CLPVTPNDBS01 CLPVTPNDBS03"
rm -rf dbServiceStatus.log
rm -rf dbServiceStatusRunning.log 

for host in $servers
 do
#	echo $host >>serviceStatus.log
	echo $host:$(ssh $host 'service mysqld status') >> dbServiceStatus.log
	echo $host:$(ssh $host 'service mysqld status') >> dbServiceStatusRunning.log
done

echo $(cat dbServiceStatus.log | grep "mysqld is stopped" | cut -d: -f1) > dbServiceStatus.log
echo $(cat dbServiceStatusRunning.log | grep "is running..." | cut -d: -f1) > dbServiceStatusRunning.log
#echo $myArray[0]

#eeho $(cat serviceStatus.log | cut -d" " -f1)
serverName=$(awk -F ' ' '{print $1}' dbServiceStatus.log)
myarray[1]=$serverName
serverName=$(awk -F ' ' '{print $2}' dbServiceStatus.log)
myarray[2]=$serverName
serverName=$(awk -F ' ' '{print $3}' dbServiceStatus.log)
myarray[3]=$serverName
echo ${myarray[@]}

appServerName=$(awk -F ' ' '{print $1}' dbServiceStatusRunning.log)
appServerArray[1]=$appServerName
appServerName=$(awk -F ' ' '{print $2}' dbServiceStatusRunning.log)
appServerArray[2]=$appServerName
appServerName=$(awk -F ' ' '{print $3}' dbServiceStatusRunning.log)
appServerArray[3]=$appServerName
echo ${appServerArray[@]}


#EVAL="db.mycollection.find({\"hostName\":\"${myarray[1]\"})"
#echo $EVAL | mongo localhost:27017/dashboard --quiet

for i in {1..3}
do
	#mongo localhost:27017/dashboard  -eval "db.mycollection.find({\"hostName\":\"${myarray[i]}\"})"
 	# mongo localhost:27017/dashboard  -eval	"db.mycollection.update({\"hostName\":\"${myarray[i]}\",\"status\" : \"False\"})"
	# mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"${myarray[i]}\"},{$setV:{\"DBstatus\":\"False\"}})"
#	mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${myarray[i]}\"},{\"type\" : \"DBServer\"}]},{$setV:{\"DBstatus\":\"False\"}})"

mysql --host=10.77.81.156 --user=pforecaster --password=mysql dashboard <<+MYSQL+
 update environment_genei set Appstatus='False' where hostName='${myarray[i]}' and serverType='DBServer';
+MYSQL+


done

for i in {1..3}
do
        #mongo localhost:27017/dashboard  -eval "db.mycollection.find({\"hostName\":\"${myarray[i]}\"})"
        # mongo localhost:27017/dashboard  -eval        "db.mycollection.update({\"hostName\":\"${myarray[i]}\",\"status\" : \"False\"})"
        # mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"${appServerArray[i]}\"},{$setV:{\"DBstatus\":\"True\"}})"
#	 mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${appServerArray[i]}\"},{\"type\" : \"DBServer\"}]},{$setV:{\"DBstatus\":\"True\"}})"

mysql --host=10.77.81.156 --user=pforecaster --password=mysql dashboard <<+MYSQL+
 update environment_genei set Appstatus='True' where hostName='${appServerArray[i]}' and serverType='DBServer';
+MYSQL+

done

 
<<comment
while read line
do
echo $line 
myarray=$(echo $line | grep "not running" | cut -d: -f1)
done <serviceStatus.log
echo $myarray[@]
comment
