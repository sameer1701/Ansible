#!/bin/bash
setV='$set'
andq='$and'
servers="CLPVDPNSVN01 CLPVTPNDBS01 CLPVTPNDBS03 CLPVTPNDBS02"

rm -rf size.log

for host in $servers
do
	echo $(ssh $host df -h /data | tail -n 1 | awk '{print $3}') >> size.log
	
done

echo $(cat size.log |  cut -d" " -f1) > size.log


server1=$(awk -F ' ' '{print $1}' size.log)
myarray[1]=$server1
server2=$(awk -F ' ' '{print $2}' size.log)
myarray[2]=$server2
server3=$(awk -F ' ' '{print $3}' size.log)
myarray[3]=$server3
server4=$(awk -F ' ' '{print $4}' size.log)
myarray[4]=$server4

serversName=(test1 clpvdpnsvn01 CLPVTPNDBS01 CLPVTPNDBS03 CLPVTPNDBS02)

#echo servername1:${serversName[1]}
#mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"clpvdpnsvn01\"},{$setV:{\"available_size\":\"$server1\"}})"
#mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"CLPVTPNDBS01\"},{$setV:{\"available_size\":\"$server2\"}})"
#mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"CLPVTPNDBS03\"},{$setV:{\"available_size\":\"$server3\"}})"
#mongo localhost:27017/dashboard  -eval "db.mycollection1.update({\"hostName\" : \"CLPVTPNDBS02\"},{$setV:{\"available_size\":\"$server4\"}})"

for i in {1..4}
do
        mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${serversName[i]}\"},{\"type\" : \"appserver\"}]},{$setV:{\"available_size\":\"${myarray[i]}\"}})"
	mongo localhost:27017/dashboard  -eval  "db.mycollection1.update({$andq: [{\"hostName\" : \"${serversName[i]}\"},{\"type\" : \"DBServer\"}]},{$setV:{\"available_size\":\"${myarray[i]}\"}})"

done



